use warnings;
use List::MoreUtils qw(uniq);

#print "contructing bins\t";
open A, "prereq_chr$ARGV[0]", or die;
my @pre = <A>;
chomp @pre;
my ($r, $s, $x_min, $x_max, $y_min, $y_max, $z_min, $z_max, $min, $max, $p, $reso1, $reso2, $g_res) = split /\t/, $pre[1];
my %bins;
close A;

$reso1 = "${reso1}r";
$reso2 = "b${reso2}";

$pd = "sa_chr$ARGV[0]_100kb_${reso1}_${reso2}.pdb";

open C, ">bin_chr$ARGV[0]", or die;
for ($i = sprintf("%.5f", ($x_min - 5*$s)); $i <= sprintf("%.5f", ($x_max + 5*$s)); $i = sprintf("%.5f", ($i + $s)))
{
	for ($j = sprintf("%.5f", ($y_min - 5*$s)); $j <= sprintf("%.5f", ($y_max + 5*$s)); $j = sprintf("%.5f", ($j + $s)))
	{
		for ($k = sprintf("%.5f", ($z_min - 5*$s)); $k <= sprintf("%.5f", ($z_max + 5*$s)); $k = sprintf("%.5f", ($k + $s)))
		{
			$bins{$i}{$j}{$k} = "e";
			print C "$i\t$j\t$k\n";
			
			
			push @xb1, $i;
			push @yb1, $j;
			push @zb1, $k;
			#print "$i\t$j\t$k\n";
		}
	}
}
close C;
#print "done\n";
@xb = uniq @xb1;
@yb= uniq @yb1;
@zb = uniq @zb1;
undef @xb1; undef @yb1; undef @zb1;
#print "xb\t@xb\nyb\t@yb\nzbt@zb\n";

=head

print "assigning bins\t";
open A, "sphere_1.txt", or die;
while (<A>)
{
	chomp $_;
	$_ =~ s/\r//g;
	@a = split /\t/, $_;
	foreach $ii (keys %bins)
	{
		foreach $jj (keys %{$bins{$ii}})
		{
			foreach $kk (keys %{$bins{$ii}{$jj}})
			{
				$bins{$ii}{$jj}{$kk} = "C"
				if (($a[0] > $ii)
				&& ($a[0] <= ($ii + $s))
				&& ($a[1] > $jj)
				&& ($a[1] <= ($jj + $s))
				&& ($a[2] > $kk)
				&& ($a[2] <= ($kk + $s))
				);
			}
		}
	}
}
close A;

=cut
$ite = 0;
#print "assigning bins\t";
#open A, "points.txt", or die;
open A, "sphere_1_chr$ARGV[0].txt" or die;
while (<A>)
{
	chomp $_;
	$_ =~ s/\r//g;
	@a = split /\t/, $_;
	$x = $a[0];
	$y = $a[1];
	$z = $a[2];
	$pos = $a[3];
	$X = 0;
	$Y = 0;
	$Z = 0;
############################################# BINARY SEARCH ###############################################
	$low_x = 0;
	$high_x = scalar @xb;
	$found_x = 0;
	#print "$ite\t$_\n";
	#print "scalar_x $high_x\n";
	while (($low_x <= $high_x) && ($found_x == 0))
	{	
		$mid1_x = int (($low_x + $high_x) / 2);
		$mid2_x = $mid1_x + 1;
		#print "x_check: $mid1_x\t$mid2_x\t$low_x\t$high_x\t$xb[$mid1_x]\t$xb[$mid2_x]\n";
		if (($x >= $xb[$mid1_x]) && ($x < $xb[$mid2_x]))
		{
			$found_x = 1;
		} 
		elsif ($x < $xb[$mid1_x])
		{
			$high_x = $mid1_x - 1;
		}
		else
		{
			$low_x = $mid1_x + 1;
		}
		#print "x_check: $mid1_x\t$mid2_x\t$low_x\t$high_x\txb[$mid1_x]\t$xb[$mid2_x]\n";
	}
	#print "case1:$xb[$mid1_x]\t$xb[$mid2_x]\n";
	if ($found_x == 1)
	{
		#print "bin found_x\tbin1_x : $xb[$mid1_x]\tmid1_x : ß$mid1_x\tbin2_x : $xb[$mid2_x]\tmid2_x : $mid2_x\n";
		$X = $xb[$mid1_x];
		$low_y = 0;
		$high_y = scalar @yb;
		$found_y = 0;
		#ßprint "scalar_y $high_y\n";
		while (($low_y <= $high_y) && ($found_y == 0))
		{	
			
			$mid1_y = int (($low_y + $high_y) / 2);
			$mid2_y = $mid1_y + 1;
			#print "y_check: $mid1_y\t$mid2_y\t$low_y\t$high_y\t$yb[$mid1_y]\t$yb[$mid2_y]\n";
			#print "check: $mid1_y\t$mid2_y\t$yb[$mid1_y]\t$yb[$mid2_y]\n";
			if (($y >= $yb[$mid1_y]) && ($y < $yb[$mid2_y]))
			{
				$found_y = 1;
			}
			elsif ($y < $yb[$mid1_y])
			{
				$high_y = $mid1_y - 1;
			}
			else
			{
				$low_y = $mid1_y + 1;
			}
			
		}
		#print "case2:$yb[$mid1_y]\t$yb[$mid2_y]\n";
		if ($found_y == 1)
		{
			#print "bin found_y\tbin1_y : $yb[$mid1_y]\tmid1_y : $mid1_y\tbin2_y : $yb[$mid2_y]\tmid2_y : $mid2_y\n";
			$Y = $yb[$mid1_y];
			$low_z = 0;
			$high_z = scalar @zb;
			$found_z = 0;
			#print "z: $low_z\t$high_z\n";
			while (($low_z <= $high_z) && ($found_z == 0))
			{
				$mid1_z = int (($low_z + $high_z) / 2);
				$mid2_z = $mid1_z + 1;
				#print "z_check: $mid1_z\t$mid2_z\t$low_z\t$high_z\t$zb[$mid1_z]\t$zb[$mid2_z]\n";
				if (($z >= $zb[$mid1_z]) && ($z < $zb[$mid2_z]))
				{
					$found_z = 1;
				}
				elsif ($z < $zb[$mid1_z])
				{
					$high_z = $mid1_z - 1;
				}
				else
				{
					$low_z = $mid1_z + 1;
				}
			}
			#print "case3:$zb[$mid1_z]\t$zb[$mid2_z]\n";
			if ($found_z)
			{
				#print "bin found_z\tbin1_z : $zb[$mid1_z]\tmid1_z : $mid1_z\tbin2_z : $zb[$mid2_z]\tmid2_z : $mid2_z\n";
				$Z = $zb[$mid1_z];
				#print "$bins{$xb[$mid1_x]}{$yb[$mid1_y]}{$zb[$mid1_z]}\n";
				if (exists $bins{$xb[$mid1_x]}{$yb[$mid1_y]}{$zb[$mid1_z]})
				{
					$bins{$xb[$mid1_x]}{$yb[$mid1_y]}{$zb[$mid1_z]} = "C:${pos}";
					#print "yup\n";
					#print "$bins{$xb[$mid1_x]}{$yb[$mid1_y]}{$zb[$mid1_z]}\n";
				}
				
			}
		
		}
		
	}
	else
	{
		#print "bin not found\n";
	}
	#print "$X\t$Y\t$Z\n";
###########################################################################################################		
$ite += 1;

}
#print "done\t";


#print "assigning surface bins\t";
my %total_surface_accessibility_score;
open A, "> bin_names_chr$ARGV[0].txt", or die;
foreach $k1 (keys %bins)
{
	foreach $k2 (keys %{$bins{$k1}})
	{
		foreach $k3 (keys %{$bins{$k1}{$k2}})
		{
			print A "$k1\t$k2\t$k3\t$bins{$k1}{$k2}{$k3}\n";
			if ($bins{$k1}{$k2}{$k3} eq "e")
			{
				$index1 = 0;
				$k1i = $k1 - $s;
				$k1a = $k1 + $s;
				$k2i = $k2 - $s;
				$k2a = $k2 + $s;
				$k3i = $k3 - $s;
				$k3a = $k3 + $s;
				
				$k1i = sprintf ("%.5f", $k1i);
				$k1a = sprintf ("%.5f", $k1a);
				$k2i = sprintf ("%.5f", $k2i);
				$k2a = sprintf ("%.5f", $k2a);
				$k3i = sprintf ("%.5f", $k3i);
				$k3a = sprintf ("%.5f", $k3a);
=asd				
				$index1 ++ if (($k1 < ($x_max + 4*$s)) && ($bins{$k1a}{$k2}{$k3} =~ m/C/g));
				$index1 ++ if (($k1 > ($x_min - 4*$s)) && ($bins{$k1i}{$k2}{$k3} =~ m/C/g));				
				$index1 ++ if (($k2 < ($y_max + 4*$s)) && ($bins{$k1}{$k2a}{$k3} =~ m/C/g));				
				$index1 ++ if (($k2 > ($y_min + 4*$s)) && ($bins{$k1}{$k2i}{$k3} =~ m/C/g));				
				$index1 ++ if (($k3 < ($z_max + 4*$s)) && ($bins{$k1}{$k2}{$k3a} =~ m/C/g));			
				$index1 ++ if (($k3 > ($z_min - 4*$s)) && ($bins{$k1}{$k2}{$k3i} =~ m/C/g));
				#print "$index1\n";
=cut			
				undef @positions;
				if (($k1 < ($x_max + 4*$s)) && ($bins{$k1a}{$k2}{$k3} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1a}{$k2}{$k3})[1];
					push @positions, $p;
				}
				if (($k1 > ($x_min - 4*$s)) && ($bins{$k1i}{$k2}{$k3} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1i}{$k2}{$k3})[1];
					push @positions, $p;
				}
				if (($k2 < ($y_max + 4*$s)) && ($bins{$k1}{$k2a}{$k3} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1}{$k2a}{$k3})[1];
					push @positions, $p;
				}
				if (($k2 > ($y_min + 4*$s)) && ($bins{$k1}{$k2i}{$k3} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1}{$k2i}{$k3})[1];
					push @positions, $p;
				}
				if (($k3 < ($z_max + 4*$s)) && ($bins{$k1}{$k2}{$k3a} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1}{$k2}{$k3a})[1];
					push @positions, $p;
				}
				if (($k3 > ($z_min - 4*$s)) && ($bins{$k1}{$k2}{$k3i} =~ m/C/g))
				{
					$index1 ++;
					$p = (split /\:/, $bins{$k1}{$k2}{$k3i})[1];
					push @positions, $p;
				}
				if (($index1 <= 5) && ($index1 > 0))
				{
					#print "################################################################################\n";
					#local $" = "\t";
					#print "@positions\n";
					$p0 = shift @positions;
					undef @positions;
					#$total_surface_accessibility_score{$p0} = 0;
					$bins{$k1}{$k2}{$k3} = "S:$p0";
					$total_surface_accessibility_score{$p0} ++;
					#print "$bins{$k1}{$k2}{$k3}\n";
				}					
			}	
		}
	}
}
close A;
#print "done\n";
#print "printing\t";

				
open OUT, ">Total_surface_accessibility_chr$ARGV[0]_${reso1}_${reso2}", or die;
print OUT "genomic_coordinate\ttotal_surface_accessibility_score\n";
foreach my $counts (keys %total_surface_accessibility_score)
{
	print OUT "$counts\t$total_surface_accessibility_score{$counts}\n";
}
close OUT;
#print "TSAS file saved\n";


open A, ">surface_area_chr$ARGV[0].txt", or die;
open B, ">final_bins_${reso1}_${reso2}_chr$ARGV[0]", or die;
print A "x\ty\tz\tbin_type\n";
foreach $k1 (keys %bins)
{
	foreach $k2 (keys %{$bins{$k1}})
	{
		foreach $k3 (keys %{$bins{$k1}{$k2}})
		{
			$kk1 = sprintf ("%.5f", $k1 + ($s/2));
			$kk2 = sprintf ("%.5f", $k2 + ($s/2));
			$kk3 = sprintf ("%.5f", $k3 + ($s/2));
			print B "$k1\t$k2\t$k3\t$bins{$k1}{$k2}{$k3}\n";
			print A "$kk1\t$kk2\t$kk3\t$bins{$k1}{$k2}{$k3}\n" if ($bins{$k1}{$k2}{$k3} =~ m/S/g);
		}
	}
}
close A;
close B;

#print "done\n";
open A, "surface_area_chr$ARGV[0].txt", or die;
open B, "> surface_area_points_chr$ARGV[0].txt", or die;
@sa = <A>;
for ($i = 1; $i < scalar @sa; $i++)
{
	chomp $sa[$i];
	print B "$sa[$i]\n" if ($sa[$i] =~ S);
}
close A;
close B;

#print "converting to PDB\t";
for (1..50){
    $i++;
    open T, "surface_area_points_chr$ARGV[0].txt" or die;
    open TO, ">$pd" or die;
    while (<T>)
	{
		chomp $_;
        $_ =~ s/\r//g;
        @a =split /\t/, $_;
        if ($a[1] ne "nan")
		{
            if ($a[2] ne "nan")
			{
                if ($a[3] ne "nan")
				{
                    $line++;
                    print TO "ATOM  ";
                    $len =length($line);
                    $times =11-($len+6);
                    for(1..$times)
					{
                        print TO " ";
                    }
                    print TO "$line";
                    print TO "  CA  ARG A";
                    $times =4-$len;
                    for(1..$times)
					{
                        print TO " ";
                    }
                    if ($line < 10000)
					{
						print TO "$line    ";
					}
					else
					{
						print TO "$line   ";
					}                   
                    $x = sprintf ("%.3f", $a[0]);
                    $times =8-length $x;
                    for(1..$times)
					{
                        print TO " ";
                    }
                    print TO "$x";
                    $y = sprintf ("%.3f", $a[1]);
                    $times =8-length $y;
                    for(1..$times)
					{
                        print TO " ";
                    }
                    print TO "$y";
                    $z = sprintf ("%.3f", $a[2]);
                    $times =8-length $z;
                    for(1..$times)
					{
                        print TO " ";
                    }
                    print TO "$z";
                    for (1..23)
					{
                        print TO " ";
                    }
                    print TO "C\n";
                }
            }
        }
    }
    undef $line;
    last;
}
close T;
close TO;
#print "done\n";
unlink "surface_area_points_chr$ARGV[0].txt";
unlink "final_bins_${reso1}_${reso2}_chr$ARGV[0]";
unlink "surface_area_chr$ARGV[0].txt";
unlink "bin_names_chr$ARGV[0].txt";
unlink "bin_chr$ARGV[0]";
unlink "sphere_1_chr$ARGV[0].txt";
