use warnings;

foreach my $i (1..22, "X", "Y")
{
	`perl surface_1.pl $i`;
	`perl surface_2.pl $i`;
	print "chr $i done\n";
}
