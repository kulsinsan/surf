use warnings;

#my @files = glob "*_20kb_model_PDB.pdb";
#undef @files;

my @files;
push @files, "pdb_hg19_chr$ARGV[0]_human_NPC_50kb_200kb_model_with_coords.pdb";
my (@x_bin, @y_bin, @z_bin);
my %coords;

foreach my $i (@files)
{
	open PDB, "${i}", or die;
	while (<PDB>)
	{
		chomp $_;
		my @a = split /\t/, $_;
		my $x = substr $a[0], 31, 7;
		my $y = substr $a[0], 39, 7;
		my $z = substr $a[0], 47, 7;
		
		$x =~ s/^\s+|\s+$//g;
		$y =~ s/^\s+|\s+$//g;
		$z =~ s/^\s+|\s+$//g;
				
		push @x_bin, $x;
		push @y_bin, $y;
		push @z_bin, $z;
	}
	
	$x_min = (sort {$a <=> $b} @x_bin) [0];
	$x_max = (sort {$b <=> $a} @x_bin) [0];
	$y_min = (sort {$a <=> $b} @y_bin) [0];
	$y_max = (sort {$b <=> $a} @y_bin) [0];
	$z_min = (sort {$a <=> $b} @z_bin) [0];
	$z_max = (sort {$b <=> $a} @z_bin) [0];
	
	undef @x_bin;
	undef @y_bin;
	undef @z_bin;
	
	$coords {$i} = "$x_min:$x_max:$y_min:$y_max:$z_min:$z_max";
	#print "coords : $x_min:$x_max:$y_min:$y_max:$z_min:$z_max \n";
	close PDB;
}


my @bins;
my %prereq;

foreach my $k1 (keys %coords)
{
	my $chr = $k1;
	$chr =~ s/_20kb_model_PDB.pdb//g;
	my ($x_min, $x_max, $y_min, $y_max, $z_min, $z_max) = split /\:/, $coords {$k1};
	push @bins, $x_max - $x_min, $y_max - $y_min, $z_max - $z_min;
	my $sortest_dim = (sort {$a <=> $b} @bins) [0];
	undef @bins;
	
	my $bin = $sortest_dim / 10;										##--##-- bin size --##--##
	
	$prereq {$k1} = "$bin:$x_min:$x_max:$y_min:$y_max:$z_min:$z_max";
	#print "bins : $bin:$x_min:$x_max:$y_min:$y_max:$z_min:$z_max \n";
}
my $bin = $sortest_dim / 10;

my %bins;
my %chromosome_density;

foreach my $k1 (keys %prereq)
{
	my ($bin, $x_min, $x_max, $y_min, $y_max, $z_min, $z_max) = split /\:/, $prereq {$k1};
	
	for ($i = ($x_min - (5 * $bin)); $i <= ($x_max + (5 * $bin)); $i = $i + $bin)
	{
		for ($j = ($y_min - (5 * $bin)); $j <= ($y_max + (5 * $bin)); $j = $j + $bin)
		{
			for ($k = ($z_min - (5 * $bin)); $k <= ($z_max + (5 * $bin)); $k = $k + $bin)
			{
				$i = sprintf ("%0.3f", $i);
				$j = sprintf ("%0.3f", $j);
				$k = sprintf ("%0.3f", $k);
				$bins {$i} {$j} {$k} ++;
			}
		}
	}


	open PDB, "${k1}", or die;
	while (<PDB>)
	{
		chomp $_;
		my $x = substr $_, 31, 7;
		my $y = substr $_, 39, 7;
		my $z = substr $_, 47, 7;
		
		$x =~ s/^\s+|\s+$//g;
		$y =~ s/^\s+|\s+$//g;
		$z =~ s/^\s+|\s+$//g;
		
		my @x_range = sort {$a <=> $b} keys %bins;
		my $low_x = 0;
		my $high_x = scalar @x_range - 1;
		my $mid1_x = 0;
		my $mid2_x = 0;
		my $found_x = 0;
		
		while (($low_x <= $high_x) && ($found_x == 0))
		{
			$mid1_x = int (($high_x + $low_x) / 2);
			$mid2_x = $mid1_x + 1;
			#print "X1 :: $x \t $high_x \t $mid1_x \t $x_range[$mid1_x] \t $mid2_x \t $x_range[$mid2_x]\n";
			if (($x >= $x_range[$mid1_x]) && ($x < $x_range[$mid2_x]))
			{
				$found_x = 1;
			}
			elsif ($x < $x_range [$mid1_x])
			{
				$high_x = $mid1_x - 1;
			}
			else
			{
				$low_x = $mid1_x + 1;
			}
		}
		
		if ($found_x == 1)
		{
			my $X = $x_range[$mid1_x];
			undef @x_range;
			my @y_range = sort {$a <=> $b} keys %{$bins{$X}};
			my $low_y = 0;
			my $high_y = scalar @y_range - 1;
			my $mid1_y = 0;
			my $mid2_y = 0;
			my $found_y = 0;
			
			while (($low_y <= $high_y) && ($found_y == 0))
			{
				$mid1_y = int (($high_y + $low_y) / 2);
				$mid2_y = $mid1_y + 1;
				#print "Y1 :: $y \t $high_y \t $mid1_y \t $y_range[$mid1_y] \t $mid2_y \t $y_range[$mid2_y]\n";
				if (($y >= $y_range[$mid1_y]) && ($y < $y_range[$mid2_y]))
				{
					$found_y = 1;
				}
				elsif ($y < $y_range[$mid1_y])
				{
					$high_y = $mid1_y - 1;
				}
				else
				{
					$low_y = $mid1_y + 1;
				}
			}
			
			if ($found_y == 1)
			{
				my $Y = $y_range[$mid1_y];
				undef @y_range;
				my @z_range = sort {$a <=> $b} keys %{$bins{$X}{$Y}};
				my $low_z = 0;
				my $high_z = scalar @z_range - 1;
				my $mid1_z = 0;
				my $mid2_z = 0;
				my $found_z = 0;
				
				while (($low_z <= $high_z) && ($found_z == 0))
				{
					$mid1_z = int (($high_z + $low_z) / 2);
					$mid2_z = $mid1_z + 1;
					#print "Z1 :: $z \t $high_z \t $mid1_z \t $z_range[$mid1_z] \t $mid2_z \t $z_range[$mid2_z]\n";
					if (($z >= $z_range[$mid1_z]) && ($z < $z_range[$mid2_z]))
					{
						$found_z = 1;
					}
					elsif ($z < $z_range[$mid1_z])
					{
						$high_z = $mid1_z - 1;
					}
					else
					{
						$low_z = $mid1_z + 1;
					}
				}
				
				if ($found_z == 1)
				{
					my $Z = $z_range[$mid1_z];
					undef @z_range;
					
					$X = sprintf ("%0.3f", $X);
					$Y = sprintf ("%0.3f", $Y);
					$Z = sprintf ("%0.3f", $Z);
					
					$chromosome_density {$X} {$Y} {$Z} ++;
					#my $xx = $X + $bin/2;
					#my $yy = $Y + $bin/2;
					#my $zz = $Z + $bin/2;
					#$chromosome_density {$xx} {$yy} {$zz} ++;
				}
			}
		}
	}
	undef %bins;
	close PDB;
}

open OUT, ">chr$ARGV[0]_chromosomal_density_bins_start_coords.txt", or die;
print OUT "x\ty\tz\tdensity\n";
foreach my $k1 (sort {$a <=> $b} keys %chromosome_density)
{
	foreach my $k2 (sort {$a <=> $b} keys %{$chromosome_density{$k1}})
	{
		foreach my $k3 (sort {$a <=> $b} keys %{$chromosome_density{$k1}{$k2}})
		{
			print OUT "$k1\t$k2\t$k3\t$chromosome_density{$k1}{$k2}{$k3}\n";
		}
	}
}
close OUT;

open OUT, ">chr$ARGV[0]_chromosomal_density.pdb", or die;
foreach my $i (@files)
{
	open PDB, "${i}", or die;
	while (<PDB>)
	{
		chomp $_;
		my @a = split /\t/, $_;
		my $x = substr $a[0], 31, 7;
		my $y = substr $a[0], 39, 7;
		my $z = substr $a[0], 47, 7;
		
		print "$x\t$y\t$z\n";

		$x =~ s/^\s+|\s+$//g;
		$y =~ s/^\s+|\s+$//g;
		$z =~ s/^\s+|\s+$//g;
		
		my @x_range = sort {$a <=> $b} keys %chromosome_density;
		my $low_x = 0;
		my $sx = scalar @x_range;
		my $high_x = scalar @x_range - 1;
		my $mid1_x = 0;
		my $mid2_x = 0;
		my $found_x = 0;
		
		while (($low_x <= $high_x) && ($found_x == 0))
		{
			$mid1_x = int (($high_x + $low_x) / 2);
			$mid2_x = $mid1_x + 1;
			if (($x >= $x_range[$mid1_x]) && ($x < $x_range[$mid2_x]))
			{
				$found_x = 1;
			}
			elsif ($x < $x_range[$mid1_x])
			{
				$high_x = $mid1_x - 1;
			}
			else
			{
				$low_x = $mid1_x + 1;
			}
			#print "X \t $x \t $low_x : $x_range[$low_x] \t || $sx || \t $high_x : $x_range[$high_x] \t $mid1_x : $x_range[$mid1_x] \n";
			#print "X \t $x \t $low_x \t $high_x \t $mid1_x \n";
		}
	
		if ($found_x == 1)
		{
			my $X = $x_range[$mid1_x];
			undef @x_range;
			my @y_range = sort {$a <=> $b} keys %{$chromosome_density{$X}};
			my $low_y = 0;
			my $sy = scalar @y_range;
			my $high_y = scalar @y_range - 1;
			my $mid1_y = 0;
			my $mid2_y = 0;
			my $found_y = 0;
			
			while (($low_y <= $high_y) && ($found_y == 0))
			{
				$mid1_y = int (($high_y + $low_y) / 2);
				$mid2_y = $mid1_y + 1;
				print "Y :: $y\t$sy\t$mid1_y\t$y_range[$mid1_y]\t$mid2_y\t$y_range[$mid2_y]\n";
				if (($y >= $y_range[$mid1_y]) && ($y < $y_range[$mid2_y]))
				{
					$found_y = 1;
				}
				elsif ($y < $y_range[$mid1_y])
				{
					$high_y = $mid1_y - 1;
				}
				else
				{
					$low_y = $mid1_y + 1;
				}
				#print "Y \t $y \t $low_y : $y_range[$low_y] \t || $sy || \t $high_y : $y_range[$high_y] \t $mid1_y : $y_range[$mid1_y] \n";
				#print "Y \t $y \t $low_y \t $high_y \t $mid1_y \n";
			}
			
			if ($found_y == 1)
			{
				my $Y = $y_range[$mid1_y];
				undef @y_range;
				my @z_range = sort {$a <=> $b} keys %{$chromosome_density{$X}{$Y}};
				my $low_z = 0;
				my $sz = scalar @z_range;
				my $high_z = scalar @z_range - 1;
				my $mid1_z = 0;
				my $mid2_z = 0;
				my $found_z = 0;
				
				while (($low_z <= $high_z) && ($found_z == 0))
				{
					$mid1_z = int (($high_z + $low_z) / 2);
					$mid2_z = $mid1_z + 1;
					local $" = "\t";
					#print "@z_range\n";
					print "Z :: $z\t$sz\t$mid1_z\t$z_range[$mid1_z]\t$mid2_z\t$z_range[$mid2_z]\n";
					if (($z >= $z_range[$mid1_z]) && ($z < $z_range[$mid2_z]))
					{
						$found_z = 1;
					}
					elsif ($z < $z_range[$mid1_z])
					{
						$high_z = $mid1_z - 1;
					}
					else
					{
						$low_z = $mid1_z + 1;
					}
					#print "Z \t $z \t $low_z : $z_range[$low_z] \t || $sz || \t $high_z : $z_range[$high_z] \t $mid1_z : $z_range[$mid1_z] \n";
					#print "Z \t $z \t $low_z \t $high_z \t $mid1_z \n";
				}
				
				if ($found_z == 1)
				{
					my $Z = $z_range[$mid1_z];
					undef @z_range;
					
					my $density = $chromosome_density{$X}{$Y}{$Z};
					$density = sprintf ("%.05d", $density);
					substr $_, 61, 5, $density;
					print OUT "$_\n";
				}
			}
		}
	}
}

undef %chromosome_density;
close OUT;
