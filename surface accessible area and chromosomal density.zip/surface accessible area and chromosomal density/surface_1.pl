use warnings;
use List::Util qw(sum);

#$pdb = "chr$ARGV[0]_normObs_gm12878_25kbres_250kbskeleton_m0.01_p0.001.pdb";
$pdb = "pdb_hg19_chr$ARGV[0]_human_NPC_50kb_200kb_model_with_coords.pdb";
open A,"$pdb", or die;
my @dist;
@pdb = <A>;
chomp @pdb;
#print "calculating uclidian distance\t";
for ($i = 1; $i < scalar @pdb - 1; $i = $i + 1)
{
	next if ($pdb[$i] =~ m/END/g);
	next if ($pdb[$i] =~ m/CONECT/g);
	next if ($pdb[$i] =~ m/coordinate/g);
	#if ($pdb[$i] =~ m/^[ATOM]/g)
	if ($pdb[$i] =~ m/^ATOM/g)
	{
		$i =~ s/\r//g;
		if ($pdb[$i-1] !~ m/NA|(NA$)/g)
		{
			@a0 = split /\t/, $pdb[$i-1];
		}
		if ($pdb[$i] !~ m/NA|(NA$)/g)
		{
			@a1 = split /\t/, $pdb[$i];
		}
		#print "$a1\n";
		$x0 = substr $pdb[$i-1], 30, 8;
		#$x0 = $a0[3];
		$y0 = substr $pdb[$i-1], 38, 8;
		#$y0 = $a0[4];
		$z0 = substr $pdb[$i-1], 46, 8;
		#$z0 = $a0[5];
		$x1 = substr $pdb[$i], 30, 8;
		#$x1 = $a1[3];
		$y1 = substr $pdb[$i], 38, 8;
		#$y1 = $a1[4];
		$z1 = substr $pdb[$i], 46, 8;
		#$z1 = $a1[5];
		
		$x0 =~ s/^\s+|\s+$//g;
		$y0 =~ s/^\s+|\s+$//g;
		$z0 =~ s/^\s+|\s+$//g;
		$x1 =~ s/^\s+|\s+$//g;
		$y1 =~ s/^\s+|\s+$//g;
		$z1 =~ s/^\s+|\s+$//g;
		
		#my ($x0, $y0, $z0) = (split /\s+/, $pdb[$i-1]) [5..7];
		#my ($x1, $y1, $z1) = (split /\s+/, $pdb[$i]) [5..7];
		$d = sqrt(($x1-$x0)**2 + ($y1-$y0)**2 + ($z1-$z0)**2);
		#print "$x0 : $y0 : $z0 \t $x1 : $y1 : $z1 \t $d \n";
		push @dist, $d;
		#print "$d\n";
	}
}
close A;
undef @a0;
undef @a1;

my $radius_multiplier = 1.5;
my $bin_divisor = 6;

$r = (((sum(@dist)/@dist)*0.75)/2)*$radius_multiplier;							#-------------- radius --------------#
$s = $r/$bin_divisor;															#------------- bin size -------------#
$g_res = 50000;																	#---------genomic resolution---------#

open A, "> sphere_1_chr$ARGV[0].txt", or die;
open B, "$pdb", or die;
my @x_range;
my @y_range;
my @z_range;

while (<B>)
{
	chomp $_;
	$_ =~ s/\r//g;
	#if ($_ =~ /ATOM/g)
	@a = split /\t/, $_;
	
	if ($a[0] !~ m/number/g)
	{
		#my ($xx, $yy, $zz) = (split /\s+/, $_) [5..7];
	
		$xx = substr $_, 30, 8;
		$yy = substr $_, 38, 8;
		$zz = substr $_, 46, 8;
		$pos = substr $_, 5, 7;
		$xx =~ s/^\s+|\s+$//g;
		$yy =~ s/^\s+|\s+$//g;
		$zz =~ s/^\s+|\s+$//g;
		$pos =~ s/^\s+|\s+$//g;

		#next if ($pdb[$i] =~ m/coordinate/g);
		#$xx = $a[3];
		#$yy = $a[4];
		#$zz = $a[5];
		for ($x = -$r; $x <= $r; $x = $x + ($s/2))
		{
			for ($y = -$r; $y <= $r; $y = $y + ($s/2))
			{
				for ($z = -$r; $z <= $r; $z = $z + ($s/2))
				{
					$R = (($x**2) + ($y**2) + ($z**2));
					if ($R <= ($r**2))
					{
						push @x_range, ($x + $xx); push @y_range, ($y + $yy); push @z_range, ($z + $zz);
						print A $x + $xx, "\t", $y + $yy, "\t",$z + $zz, ,"\t", $pos * $g_res, "\n";
					}
				}
			}
		}
	}
}
close A;
close B;

#print "done\n";

my %bins;
$x_min = (sort {$a <=> $b} @x_range) [0];
$x_max = (sort {$b <=> $a} @x_range) [0];
$y_min = (sort {$a <=> $b} @y_range) [0];
$y_max = (sort {$b <=> $a} @y_range) [0];
$z_min = (sort {$a <=> $b} @z_range) [0];
$z_max = (sort {$b <=> $a} @z_range) [0];
$min = -($r + (20*$r));
$max = $r + (20*$r);

open A, "> prereq_chr$ARGV[0]", or die;
$r = sprintf ("%0.3f", $r);
$s = sprintf ("%0.3f", $s);
$x_min = sprintf ("%0.3f", $x_min);
$x_max = sprintf ("%0.3f", $x_max);
$y_min = sprintf ("%0.3f", $y_min);
$y_max = sprintf ("%0.3f", $y_max);
$z_min = sprintf ("%0.3f", $z_min);
$z_max = sprintf ("%0.3f", $z_max);
$min = sprintf ("%0.3f", $min);
$max = sprintf ("%0.3f", $max);
#print "radius\t$r\nbin_size\t$s\nx_min\t$x_min\nx_max\t$x_max\ny_min\t$y_min\ny_max\t$y_max\nz_min]t$z_min\nz_max\t$z_max\nmin\t$min\nmax\t$max\npdb\t$pdb\n";
print A "radius\tbin_size\tx_min\tx_max\ty_min\ty_max\tz_min\tz_max\tmin\tmax\tpdb\tradius_multiplier\tbin_divisor\tgenomic_resolution\n";
print A "$r\t$s\t$x_min\t$x_max\t$y_min\t$y_max\t$z_min\t$z_max\t$min\t$max\t$pdb\t$radius_multiplier\t$bin_divisor\t$g_res\n";
close A;

